package Queries

class Constants {
  companion object {
    val ERROR_STRING = "ERROR"
    val SUCCESS_STRING = "SUCCESS"
    val TRUTH_VALUE = "TRUE"
    val FALSE_VALUE = "FALSE"
  }
}
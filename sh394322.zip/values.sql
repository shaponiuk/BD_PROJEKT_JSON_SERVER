INSERT INTO zasoby VALUES (0, 'rekawiczki', 300);
INSERT INTO zasoby VALUES (1, 'lozko', 2);
INSERT INTO zasoby VALUES (2, 'bandaz', 350);

INSERT INTO statusy_uslug VALUES (0, 'umowiona');
INSERT INTO statusy_uslug VALUES (1, 'zakonczona');

INSERT INTO specjalizacje VALUES (0, 'chirurgia');
INSERT INTO specjalizacje VALUES (1, 'neurologia');

INSERT INTO lekarze VALUES (0, 'Bogdan', 'Lekarski', 0);
INSERT INTO lekarze VALUES (1, 'Abraham', 'Lekarz', 1);

INSERT INTO pacjenci VALUES (11111111111, 'Eugeniusz', 'Caweczynski');

INSERT INTO szablon_uslug VALUES (0, 0, 'operacja wyrostka robaczkowego');

INSERT INTO szablon_zasobow_uslug VALUES (0, 0, 3);

COMMIT;